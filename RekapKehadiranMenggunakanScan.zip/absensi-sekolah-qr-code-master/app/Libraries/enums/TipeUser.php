<?php

namespace App\Libraries\enums;

enum TipeUser: string
{
  case Siswa = 'id_siswa';
  case Guru = 'id_guru';
}
