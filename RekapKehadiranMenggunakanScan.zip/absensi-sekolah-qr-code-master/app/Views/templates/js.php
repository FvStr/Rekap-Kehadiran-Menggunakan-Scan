<!--   Core JS Files   -->
<script src="<?= base_url('public/assets/js/core/jquery-3.5.1.min.js') ?>"></script>
<script src="<?= base_url('public/assets/js/core/bootstrap.bundle.min.js') ?>"></script>
<script src="<?= base_url('public/assets/js/core/popper.min.js') ?>"></script>
<script src="<?= base_url('public/assets/js/core/bootstrap-material-design.min.js') ?>"></script>

<script src="<?= base_url('public/assets/js/plugins/perfect-scrollbar.jquery.min.js') ?>"></script>
<!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
<script src="<?= base_url('public/assets/js/plugins/nouislider.min.js') ?>"></script>
<!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
<script src="<?= base_url('public/assets/js/material-dashboard.js') ?>" type="text/javascript"></script>