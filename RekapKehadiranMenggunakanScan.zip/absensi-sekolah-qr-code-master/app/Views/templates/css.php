<!-- CSS Files -->
<link href="<?= base_url('public/assets/fonts/fonts.css'); ?>" rel="stylesheet" />
<link href="<?= base_url('public/assets/css/material-dashboard.css'); ?>" rel="stylesheet" />

<link rel="apple-touch-icon" sizes="76x76" href="<?= base_url('public/assets/img/apple-icon.png'); ?>">
<link rel="icon" type="image/png" href="<?= base_url('public/assets/img/favicon.png'); ?>">